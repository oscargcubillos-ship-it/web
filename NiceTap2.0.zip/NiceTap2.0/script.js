let tareas = JSON.parse(localStorage.getItem("tareas")) || [];
const vistas = document.querySelectorAll(".vista");

function mostrarVista(id) {
  vistas.forEach(v => v.style.display = "none");
  document.getElementById(id).style.display = "block";
}

document.getElementById("btn-inicio").onclick = () => mostrarVista("inicio");
document.getElementById("btn-tareas").onclick = () => mostrarVista("tareas");
document.getElementById("btn-calendario").onclick = () => mostrarVista("calendario");
document.getElementById("btn-config").onclick = () => mostrarVista("config");
document.getElementById("btn-ayuda").onclick = () => mostrarVista("ayuda");

function agregarTarea() {
  const titulo = document.getElementById("titulo").value;
  const fecha = document.getElementById("fecha").value;
  const prioridad = document.getElementById("prioridad").value;
  const dificultad = document.getElementById("dificultad").value;

  if (titulo === "") return;

  const nuevaTarea = {
    titulo,
    fecha,
    prioridad,
    dificultad,
    completada: false
  };

  tareas.push(nuevaTarea);
  localStorage.setItem("tareas", JSON.stringify(tareas));

  mostrarTareas();

  document.getElementById("titulo").value = "";
  document.getElementById("fecha").value = "";
}


function mostrarTareas() {
  const lista = document.getElementById("lista-tareas");
  lista.innerHTML = "";

  tareas.forEach((tarea, index) => {
    const div = document.createElement("div");
    div.classList.add("tarea");

    if (tarea.prioridad === "Alta") div.classList.add("alta");
    if (tarea.prioridad === "Media") div.classList.add("media");
    if (tarea.prioridad === "Baja") div.classList.add("baja");

    if (tarea.completada) {
      div.style.opacity = "0.5";
      div.style.textDecoration = "line-through";
    }

    div.innerHTML = `
      <div class="info">
        <strong>${tarea.titulo}</strong><br>
        📅 ${tarea.fecha} <br>
        🔥 ${tarea.prioridad} <br>
        🎯 ${tarea.dificultad}
      </div>
      <div class="acciones">
        <button onclick="completarTarea(${index})">✔</button>
        <button onclick="eliminarTarea(${index})">❌</button>
      </div>
    `;

    lista.appendChild(div);
  });
  actualizarEstadisticas();
}

function completarTarea(index) {
  tareas[index].completada = true;
  localStorage.setItem("tareas", JSON.stringify(tareas));
  mostrarTareas();
}
function eliminarTarea(index) {
  tareas.splice(index, 1);
  localStorage.setItem("tareas", JSON.stringify(tareas));
  mostrarTareas();
}

function actualizarEstadisticas() {
  const hoy = new Date().toISOString().split("T")[0];

  let tareasHoy = 0;
  let completadas = 0;

  tareas.forEach(t => {
    if (t.fecha === hoy) tareasHoy++;
    if (t.completada) completadas++;
  });

  const pendientes = tareas.length - completadas;

  document.getElementById("tareas-hoy").textContent = tareasHoy;
  document.getElementById("completadas").textContent = completadas;
  document.getElementById("pendientes").textContent = pendientes;
}


mostrarTareas();

